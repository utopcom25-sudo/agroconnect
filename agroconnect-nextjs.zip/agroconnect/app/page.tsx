"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import type { FormEvent } from "react";
import { Header } from "@/components/Header";
import { Button, Badge } from "@/components/ui";
import { IconCart, IconChevron, IconSprout } from "@/components/icons";

type Rol = "agricultor" | "comprador";

const ROLES: { value: Rol; titulo: string; texto: string; href: string; Icon: typeof IconSprout }[] = [
  { value: "agricultor", titulo: "Soy Agricultor", texto: "Crea el perfil de tu chacra y publica tus lotes de cosecha.", href: "/agricultor/registro", Icon: IconSprout },
  { value: "comprador", titulo: "Soy Comprador", texto: "Persona o empresa: encuentra lotes y contacta al productor.", href: "/comprador", Icon: IconCart },
];

export default function Home() {
  const router = useRouter();
  const [rol, setRol] = useState<Rol>("agricultor");

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const payload = { tipo: rol };
    console.log("[AgroConnect] Rol seleccionado:", payload);
    // SUPABASE (siguiente paso): guardar el rol elegido para el registro, p. ej.
    // sessionStorage.setItem("agro_rol", rol) o como metadata en supabase.auth.signUp()
    router.push(ROLES.find((r) => r.value === rol)!.href);
  };

  return (
    <>
      <Header links={[{ href: "/lotes", label: "Lotes en venta" }, { href: "#como-funciona", label: "Cómo funciona" }]} />

      <main className="mx-auto max-w-6xl px-6 pb-20 pt-16">
        <section className="grid items-center gap-14 md:grid-cols-2">
          <div className="flex flex-col gap-5">
            <Badge>Del campo directo al comprador</Badge>
            <h1 className="font-display text-5xl font-bold leading-[1.05] text-bosque md:text-6xl">
              Conectamos agricultores con compradores
            </h1>
            <p className="max-w-lg text-lg leading-relaxed text-musgo">
              Publica tus lotes de cosecha o encuentra producto fresco en origen. Sin intermediarios, con contacto directo por WhatsApp o correo.
            </p>
            <Link href="/lotes" className="self-start font-semibold text-hoja hover:text-bosque">Ver lotes en venta →</Link>
          </div>

          {/* Selector de rol */}
          <form onSubmit={handleSubmit} className="flex flex-col gap-5 rounded-3xl border border-borde bg-white p-8">
            <fieldset className="flex flex-col gap-4">
              <legend className="mb-1 font-display text-2xl font-semibold">¿Cómo quieres usar AgroConnect?</legend>
              <p className="mb-1 text-[15px] text-musgo">Elige tu perfil para crear tu cuenta.</p>
              {ROLES.map(({ value, titulo, texto, Icon }) => {
                const on = rol === value;
                return (
                  <label
                    key={value}
                    className={`flex cursor-pointer items-center gap-4 rounded-2xl p-5 transition ${on ? "border-2 border-hoja bg-brote" : "border border-linea bg-white hover:border-hoja"}`}
                  >
                    <input type="radio" name="rol" value={value} checked={on} onChange={() => setRol(value)} className="sr-only" />
                    <span className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl ${on ? "bg-hoja text-white" : "bg-menta text-bosque"}`}>
                      <Icon className="h-7 w-7" />
                    </span>
                    <span className="flex flex-1 flex-col gap-1">
                      <span className="font-display text-xl font-semibold">{titulo}</span>
                      <span className="text-sm text-musgo">{texto}</span>
                    </span>
                    <IconChevron className="h-5 w-5 text-hoja" />
                  </label>
                );
              })}
            </fieldset>
            <Button type="submit">Continuar</Button>
            <p className="text-center text-sm text-musgo">
              ¿Ya tienes cuenta? <Link href="#" className="font-semibold text-hoja">Inicia sesión</Link>
            </p>
          </form>
        </section>

        <section id="como-funciona" className="mt-20 grid gap-6 sm:grid-cols-3">
          {[
            ["1", "Crea tu perfil", "Agricultor con su chacra o comprador persona / empresa."],
            ["2", "Publica o explora lotes", "Producto, cantidad estimada, unidad y precio sugerido."],
            ["3", "Contacta directo", "WhatsApp, llamada o correo con el productor."],
          ].map(([n, t, d]) => (
            <div key={n} className="flex flex-col gap-2 rounded-2xl border border-borde bg-white p-6">
              <span className="font-display text-3xl font-bold text-hoja">{n}</span>
              <h3 className="font-display text-lg font-semibold">{t}</h3>
              <p className="text-sm leading-relaxed text-musgo">{d}</p>
            </div>
          ))}
        </section>
      </main>
    </>
  );
}
