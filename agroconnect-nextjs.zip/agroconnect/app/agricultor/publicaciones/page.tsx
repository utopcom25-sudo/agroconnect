import { Header } from "@/components/Header";
import { MisPublicaciones } from "@/components/MisPublicaciones";

export const metadata = { title: "Mis publicaciones | AgroConnect" };

export default function Page() {
  return (
    <>
      <Header
        links={[
          { href: "/agricultor/publicaciones", label: "Mis publicaciones", active: true },
          { href: "/lotes", label: "Lotes en venta" },
          { href: "/agricultor/finca", label: "Mi chacra" },
        ]}
      />
      <MisPublicaciones />
    </>
  );
}
