import { Header } from "@/components/Header";
import { Stepper } from "@/components/ui";
import { AgricultorDatosForm } from "@/components/forms/AgricultorDatosForm";

export const metadata = { title: "Agricultor – Datos personales | AgroConnect" };

export default async function Page({ searchParams }: { searchParams: Promise<{ correo?: string }> }) {
  const { correo } = await searchParams;
  return (
    <>
      <Header back={{ href: "/agricultor/registro" }} />
      <main className="mx-auto max-w-3xl px-6 pb-20 pt-12">
        <Stepper step={1} total={3} label="Datos personales" />
        <AgricultorDatosForm correoInicial={correo ?? ""} />
      </main>
    </>
  );
}
