import { RegistroInicio } from "@/components/RegistroInicio";

export const metadata = { title: "Agricultor – Crear cuenta | AgroConnect" };

export default function Page() {
  return (
    <RegistroInicio
      tipo="agricultor"
      badge="Cuenta de Agricultor"
      subtitulo="Publica tus cosechas y recibe contactos de compradores en todo el país."
      back="/"
      next="/agricultor/datos"
    />
  );
}
