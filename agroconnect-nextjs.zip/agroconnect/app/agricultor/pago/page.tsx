import { Header } from "@/components/Header";
import { Stepper } from "@/components/ui";
import { PagoYapeForm } from "@/components/forms/PagoYapeForm";

export const metadata = { title: "Pago con Yape | AgroConnect" };

export default async function Page({
  searchParams,
}: {
  searchParams: Promise<{ monto?: string; producto?: string; detalle?: string }>;
}) {
  const { monto, producto, detalle } = await searchParams;
  return (
    <>
      <Header back={{ href: "/agricultor/publicaciones", label: "Volver a mis publicaciones" }} />
      <main className="mx-auto max-w-5xl px-6 pb-20 pt-12">
        <Stepper step={3} total={3} label="Pago de publicación" />
        <PagoYapeForm montoInicial={monto ?? ""} producto={producto} detalle={detalle} />
      </main>
    </>
  );
}
