import { Header } from "@/components/Header";
import { Stepper } from "@/components/ui";
import { FincaForm } from "@/components/forms/FincaForm";

export const metadata = { title: "Perfil de la chacra | AgroConnect" };

export default function Page() {
  return (
    <>
      <Header back={{ href: "/agricultor/datos" }} />
      <main className="mx-auto max-w-4xl px-6 pb-20 pt-12">
        <Stepper step={2} total={3} label="Perfil de la chacra" />
        <FincaForm />
      </main>
    </>
  );
}
