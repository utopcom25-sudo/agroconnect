import { notFound } from "next/navigation";
import { Header } from "@/components/Header";
import { AccionesLote } from "@/components/AccionesLote";
import { IconPin } from "@/components/icons";
import { ENTREGAS, soles, unidadCorta } from "@/lib/constants";
import { LOTES, getLote } from "@/lib/data";

export function generateStaticParams() {
  return LOTES.map((l) => ({ id: l.id }));
}

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }) {
  const lote = getLote((await params).id);
  return { title: lote ? `${lote.producto} – ${lote.finca.nombre_finca} | AgroConnect` : "Lote | AgroConnect" };
}

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  // SUPABASE (siguiente paso):
  // const { data: lote } = await supabase.from("v_lotes_en_venta").select("*").eq("lote_id", id).single();
  // const { data: productor } = await supabase.from("v_perfil_productor").select("*").eq("finca_id", lote.finca_id).single();
  // const { data: historial } = await supabase.from("v_historial_ventas").select("*").eq("finca_id", lote.finca_id);
  const lote = getLote(id);
  if (!lote) notFound();

  const { finca, productor: p } = lote;
  const u = unidadCorta(lote.unidad);
  const fecha = lote.disponible_desde ? new Date(`${lote.disponible_desde}T00:00:00`).toLocaleDateString("es-PE") : "Inmediata";
  const detalles: [string, string][] = [
    ["Cantidad estimada", `${lote.cantidad_estimada.toLocaleString("es-PE")} ${u}`],
    ["Variedad", lote.variedad || "—"],
    ["Calidad", lote.calidad],
    ["Disponible desde", fecha],
    ["Entrega", ENTREGAS.find((e) => e.value === lote.entrega)?.label ?? "—"],
    ["Valor estimado", soles(lote.cantidad_estimada * lote.precio_sugerido)],
  ];

  return (
    <>
      <Header back={{ href: "/lotes", label: "Lotes en venta" }} />
      <main className="mx-auto flex max-w-6xl flex-col gap-7 px-6 pb-20 pt-10">
        <div className="flex flex-wrap gap-7">
          {/* Producto */}
          <section className="flex min-w-0 flex-[999_1_560px] flex-col gap-5">
            <div className="flex h-80 items-center justify-center rounded-3xl bg-brote font-medium text-musgo">Foto del producto</div>
            <div className="flex flex-col gap-5 rounded-3xl border border-borde bg-white p-7">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="flex flex-col gap-1.5">
                  <span className="self-start rounded-full bg-menta px-2.5 py-1 text-xs font-semibold text-bosque">{lote.categoria} · Disponible</span>
                  <h1 className="font-display text-4xl font-bold text-bosque">{lote.producto}</h1>
                  <span className="text-[15px] text-musgo">{finca.nombre_finca} · {finca.provincia}, {finca.departamento}</span>
                </div>
                <div className="text-right">
                  <span className="block font-display text-3xl font-bold text-hoja">{soles(lote.precio_sugerido)}</span>
                  <span className="text-sm text-musgo">precio sugerido por {u}</span>
                </div>
              </div>
              <h2 className="font-display text-xl font-semibold">Detalles del producto</h2>
              <dl className="grid gap-3.5 sm:grid-cols-2 lg:grid-cols-3">
                {detalles.map(([k, val]) => (
                  <div key={k} className="rounded-xl bg-fondo p-3.5">
                    <dt className="text-[13px] text-musgo">{k}</dt>
                    <dd className="mt-1 font-semibold">{val}</dd>
                  </div>
                ))}
              </dl>
              {lote.comentarios && <p className="text-[15px] leading-relaxed text-musgo">{lote.comentarios}</p>}
            </div>
          </section>

          {/* Productor */}
          <aside className="flex flex-[1_1_340px] flex-col gap-5">
            <div className="flex flex-col gap-4 rounded-3xl border border-borde bg-white p-6">
              <h2 className="font-display text-xl font-semibold">Perfil del productor</h2>
              <div className="flex items-center gap-3.5">
                <span aria-hidden className="flex h-16 w-16 items-center justify-center rounded-full bg-hoja font-display text-[22px] font-bold text-white">
                  {p.nombres[0]}{p.apellidos[0]}
                </span>
                <div className="flex flex-col">
                  <span className="font-display text-lg font-semibold">{p.nombres} {p.apellidos}</span>
                  <span className="text-sm text-musgo">{p.edad} años</span>
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <span className="text-sm font-semibold">Ubicación de la parcela</span>
                <div className="flex h-36 items-center justify-center gap-2 rounded-xl border border-borde bg-brote text-sm text-musgo">
                  <IconPin className="h-5 w-5 text-hoja" />
                  {finca.distrito}, {finca.provincia} – {finca.departamento}
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-3 rounded-3xl border border-borde bg-white p-6">
              <h2 className="font-display text-xl font-semibold">Historial de ventas</h2>
              {lote.historial.length === 0 ? (
                <p className="text-sm text-musgo">Aún no tiene ventas registradas en AgroConnect.</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-borde text-left text-musgo">
                        <th scope="col" className="py-2 font-semibold">Producto</th>
                        <th scope="col" className="py-2 font-semibold">Cantidad</th>
                        <th scope="col" className="py-2 text-right font-semibold">Fecha</th>
                      </tr>
                    </thead>
                    <tbody>
                      {lote.historial.map((v, i) => (
                        <tr key={i} className="border-b border-fondo">
                          <td className="py-2.5">{v.producto}</td>
                          <td className="py-2.5">{v.cantidad}</td>
                          <td className="py-2.5 text-right text-musgo">{v.fecha}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              <span className="text-[13px] text-musgo">{lote.historial.length} ventas completadas</span>
            </div>
          </aside>
        </div>

        <AccionesLote lote={lote} />
      </main>
    </>
  );
}
