import { Header } from "@/components/Header";
import { LotesExplorer } from "@/components/LotesExplorer";
import { LOTES } from "@/lib/data";

export const metadata = { title: "Lotes en venta | AgroConnect" };

export default async function Page() {
  // SUPABASE (siguiente paso):
  // const { data: lotes } = await supabase.from("v_lotes_en_venta").select("*");
  const lotes = LOTES;
  return (
    <>
      <Header links={[{ href: "/lotes", label: "Lotes en venta", active: true }, { href: "/", label: "Inicio" }]} />
      <LotesExplorer lotes={lotes} />
    </>
  );
}
