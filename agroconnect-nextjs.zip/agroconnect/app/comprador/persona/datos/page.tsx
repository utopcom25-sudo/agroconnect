import { Header } from "@/components/Header";
import { PersonaDatosForm } from "@/components/forms/PersonaDatosForm";

export const metadata = { title: "Comprador persona – Perfil | AgroConnect" };

export default async function Page({ searchParams }: { searchParams: Promise<{ correo?: string }> }) {
  const { correo } = await searchParams;
  return (
    <>
      <Header back={{ href: "/comprador/persona/registro" }} />
      <main className="mx-auto max-w-3xl px-6 pb-20 pt-12">
        <PersonaDatosForm correoInicial={correo ?? ""} />
      </main>
    </>
  );
}
