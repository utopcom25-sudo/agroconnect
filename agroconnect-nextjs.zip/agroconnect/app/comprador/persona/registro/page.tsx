import { RegistroInicio } from "@/components/RegistroInicio";

export const metadata = { title: "Comprador persona – Crear cuenta | AgroConnect" };

export default function Page() {
  return (
    <RegistroInicio
      tipo="comprador_persona"
      badge="Comprador · Persona"
      subtitulo="Encuentra lotes de cosecha y contacta directo al productor."
      back="/comprador"
      next="/comprador/persona/datos"
    />
  );
}
