import Link from "next/link";
import { Header } from "@/components/Header";
import { Badge } from "@/components/ui";
import { IconBuilding, IconUser } from "@/components/icons";

export const metadata = { title: "Comprador – Persona o empresa | AgroConnect" };

const OPCIONES = [
  { href: "/comprador/persona/registro", titulo: "Soy persona", texto: "Compras para tu hogar, bodega, restaurante o puesto de mercado.", Icon: IconUser, destacado: true },
  { href: "/comprador/empresa", titulo: "Soy empresa", texto: "Compras con RUC para distribuidora, agroexportadora o industria.", Icon: IconBuilding, destacado: false },
];

export default function Page() {
  return (
    <>
      <Header back={{ href: "/", label: "Volver al inicio" }} />
      <main className="mx-auto flex max-w-4xl flex-col gap-8 px-6 pb-20 pt-16">
        <div className="flex flex-col items-center gap-2 text-center">
          <Badge className="self-center">Cuenta de Comprador</Badge>
          <h1 className="font-display text-4xl font-bold text-bosque">¿Cómo vas a comprar?</h1>
          <p className="text-base text-musgo">Elige el tipo de cuenta que mejor te describe.</p>
        </div>
        <div className="grid gap-6 sm:grid-cols-2">
          {OPCIONES.map(({ href, titulo, texto, Icon, destacado }) => (
            <Link
              key={href}
              href={href}
              className={`flex flex-col gap-3.5 rounded-3xl bg-white p-8 transition hover:-translate-y-0.5 ${destacado ? "border-2 border-hoja" : "border border-linea hover:border-hoja"}`}
            >
              <span className={`flex h-16 w-16 items-center justify-center rounded-2xl ${destacado ? "bg-hoja text-white" : "bg-menta text-bosque"}`}>
                <Icon className="h-8 w-8" />
              </span>
              <span className="font-display text-2xl font-semibold">{titulo}</span>
              <span className="text-[15px] leading-relaxed text-musgo">{texto}</span>
              <span className="font-semibold text-hoja">Continuar →</span>
            </Link>
          ))}
        </div>
      </main>
    </>
  );
}
