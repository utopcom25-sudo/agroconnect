import { EmpresaForm } from "@/components/forms/EmpresaForm";

export const metadata = { title: "Comprador empresa | AgroConnect" };

export default function Page() {
  return (
    <main className="min-h-screen bg-bosque px-4 py-16">
      <EmpresaForm />
    </main>
  );
}
