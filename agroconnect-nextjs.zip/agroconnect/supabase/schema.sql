-- =====================================================================
--  AgroConnect – Estructura de base de datos (PostgreSQL / Supabase)
--  Conecta agricultores con compradores (personas y empresas)
-- =====================================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto";   -- gen_random_uuid()

-- ---------------------------------------------------------------------
-- Tipos (listas cerradas de valores)
-- ---------------------------------------------------------------------
CREATE TYPE tipo_usuario     AS ENUM ('agricultor', 'comprador_persona', 'comprador_empresa');
CREATE TYPE proveedor_auth   AS ENUM ('email', 'google');
CREATE TYPE unidad_medida    AS ENUM ('kg', 't', 'saco', 'caja', 'arroba', 'unidad');
CREATE TYPE estado_lote      AS ENUM ('pendiente_pago', 'activo', 'vendido', 'vencido', 'cancelado');
CREATE TYPE estado_pago      AS ENUM ('pendiente', 'validado', 'rechazado');
CREATE TYPE canal_contacto   AS ENUM ('whatsapp', 'llamada', 'correo');
CREATE TYPE forma_entrega    AS ENUM ('recojo_chacra', 'entrega_mercado', 'envio_coordinar');
CREATE TYPE tipo_riego       AS ENUM ('secano', 'gravedad', 'goteo', 'aspersion');

-- ---------------------------------------------------------------------
-- 1. USUARIOS  (agricultor, comprador persona y comprador empresa)
--    Pantallas: 02-03 (agricultor), 09-10 (persona), 11 (empresa)
-- ---------------------------------------------------------------------
CREATE TABLE usuarios (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tipo               tipo_usuario   NOT NULL,
    nombres            VARCHAR(100),
    apellidos          VARCHAR(100),
    fecha_nacimiento   DATE,
    correo             VARCHAR(150)   NOT NULL UNIQUE,
    usuario            VARCHAR(50)    UNIQUE,
    password_hash      TEXT,                          -- NULL si entra con Google
    proveedor          proveedor_auth NOT NULL DEFAULT 'email',
    google_id          VARCHAR(100)   UNIQUE,         -- "Continuar con Google"
    telefono_whatsapp  VARCHAR(20),                   -- para el botón de WhatsApp
    foto_perfil_url    TEXT,
    verificado         BOOLEAN        NOT NULL DEFAULT FALSE,
    creado_en          TIMESTAMPTZ    NOT NULL DEFAULT now(),
    actualizado_en     TIMESTAMPTZ    NOT NULL DEFAULT now(),
    CONSTRAINT chk_credenciales CHECK (
        (proveedor = 'email'  AND password_hash IS NOT NULL) OR
        (proveedor = 'google' AND google_id     IS NOT NULL)
    )
);

-- ---------------------------------------------------------------------
-- 2. FINCAS / CHACRAS  (perfil de la chacra del agricultor) – Pantalla 04
-- ---------------------------------------------------------------------
CREATE TABLE fincas (
    id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agricultor_id        UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    nombre_finca         VARCHAR(120) NOT NULL,
    nombre_productor     VARCHAR(150) NOT NULL,
    departamento         VARCHAR(60)  NOT NULL,
    provincia            VARCHAR(60),
    distrito             VARCHAR(60),
    direccion_referencia TEXT,
    latitud              NUMERIC(9,6),                -- punto del mapa
    longitud             NUMERIC(9,6),
    cultivo_principal    VARCHAR(80)  NOT NULL,
    otros_cultivos       TEXT,
    area_hectareas       NUMERIC(8,2) CHECK (area_hectareas >= 0),
    riego                tipo_riego,
    descripcion          TEXT,
    foto_url             TEXT,
    creado_en            TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_fincas_agricultor   ON fincas(agricultor_id);
CREATE INDEX idx_fincas_departamento ON fincas(departamento);

CREATE TABLE certificaciones (
    id      SERIAL PRIMARY KEY,
    nombre  VARCHAR(60) NOT NULL UNIQUE           -- Orgánico, Comercio justo, GlobalG.A.P.
);

CREATE TABLE finca_certificaciones (
    finca_id          UUID REFERENCES fincas(id) ON DELETE CASCADE,
    certificacion_id  INT  REFERENCES certificaciones(id),
    PRIMARY KEY (finca_id, certificacion_id)
);

-- ---------------------------------------------------------------------
-- 3. COMPRADORES
-- ---------------------------------------------------------------------
-- 3a. Persona – Pantalla 10
CREATE TABLE perfiles_comprador (
    usuario_id         UUID PRIMARY KEY REFERENCES usuarios(id) ON DELETE CASCADE,
    frecuencia_compra  VARCHAR(30),                 -- semanal, quincenal, mensual…
    zona_entrega       VARCHAR(150)
);

-- 3b. Empresa – Pantalla 11
CREATE TABLE empresas (
    usuario_id         UUID PRIMARY KEY REFERENCES usuarios(id) ON DELETE CASCADE,
    nombre_comercial   VARCHAR(150) NOT NULL,
    ruc                VARCHAR(20)  NOT NULL UNIQUE, -- RUC o registro fiscal
    volumen_mensual    VARCHAR(40),
    detalle_busqueda   TEXT
);

-- 3c. Preferencias de compra (persona y empresa)
CREATE TABLE categorias (
    id      SERIAL PRIMARY KEY,
    nombre  VARCHAR(60) NOT NULL UNIQUE           -- Tubérculos, Frutas, Hortalizas…
);

CREATE TABLE preferencias_compra (
    usuario_id    UUID REFERENCES usuarios(id) ON DELETE CASCADE,
    categoria_id  INT  REFERENCES categorias(id),
    PRIMARY KEY (usuario_id, categoria_id)
);

-- ---------------------------------------------------------------------
-- 4. LOTES DE COSECHA (publicaciones) – Pantallas 05, 06, 12, 13
-- ---------------------------------------------------------------------
CREATE TABLE lotes (
    id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    finca_id           UUID NOT NULL REFERENCES fincas(id) ON DELETE CASCADE,
    categoria_id       INT  REFERENCES categorias(id),
    producto           VARCHAR(100)  NOT NULL,
    variedad           VARCHAR(100),
    cantidad_estimada  NUMERIC(12,2) NOT NULL CHECK (cantidad_estimada > 0),
    unidad             unidad_medida NOT NULL,
    precio_sugerido    NUMERIC(12,2) NOT NULL CHECK (precio_sugerido >= 0), -- S/ por unidad
    valor_estimado     NUMERIC(14,2) GENERATED ALWAYS AS (cantidad_estimada * precio_sugerido) STORED,
    -- Pestaña "Detalles extra"
    calidad            VARCHAR(30),
    disponible_desde   DATE,
    entrega            forma_entrega,
    comentarios        TEXT,
    estado             estado_lote   NOT NULL DEFAULT 'pendiente_pago',
    creado_en          TIMESTAMPTZ   NOT NULL DEFAULT now(),
    publicado_en       TIMESTAMPTZ                    -- cuando se valida el pago
);
CREATE INDEX idx_lotes_finca  ON lotes(finca_id);
CREATE INDEX idx_lotes_estado ON lotes(estado);

CREATE TABLE lote_fotos (
    id       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lote_id  UUID NOT NULL REFERENCES lotes(id) ON DELETE CASCADE,
    url      TEXT NOT NULL,
    orden    SMALLINT NOT NULL DEFAULT 0
);

-- ---------------------------------------------------------------------
-- 5. PAGOS DE PUBLICACIÓN CON YAPE (7%) – Pantalla 07
-- ---------------------------------------------------------------------
CREATE TABLE pagos_publicacion (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lote_id           UUID NOT NULL REFERENCES lotes(id) ON DELETE CASCADE,
    monto_base        NUMERIC(14,2) NOT NULL,              -- valor estimado del lote
    porcentaje        NUMERIC(5,2)  NOT NULL DEFAULT 7.00,
    monto_a_pagar     NUMERIC(14,2) GENERATED ALWAYS AS (ROUND(monto_base * porcentaje / 100, 2)) STORED,
    metodo            VARCHAR(20)   NOT NULL DEFAULT 'yape',
    numero_operacion  VARCHAR(30),
    captura_url       TEXT,
    estado            estado_pago   NOT NULL DEFAULT 'pendiente',
    creado_en         TIMESTAMPTZ   NOT NULL DEFAULT now(),
    validado_en       TIMESTAMPTZ
);
CREATE INDEX idx_pagos_lote ON pagos_publicacion(lote_id);

-- ---------------------------------------------------------------------
-- 6. INTERÉS / CONTACTOS ("Estoy interesado") – Pantalla 14
-- ---------------------------------------------------------------------
CREATE TABLE contactos (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lote_id      UUID NOT NULL REFERENCES lotes(id) ON DELETE CASCADE,
    comprador_id UUID NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    canal        canal_contacto NOT NULL,
    creado_en    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_contactos_lote ON contactos(lote_id);

-- ---------------------------------------------------------------------
-- 7. VENTAS (historial de ventas del productor) – Pantalla 13
-- ---------------------------------------------------------------------
CREATE TABLE ventas (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lote_id          UUID NOT NULL REFERENCES lotes(id),
    comprador_id     UUID REFERENCES usuarios(id),
    cantidad_vendida NUMERIC(12,2) NOT NULL,
    precio_final     NUMERIC(12,2),
    fecha_venta      DATE NOT NULL DEFAULT CURRENT_DATE
);

-- ---------------------------------------------------------------------
-- Vistas para las pantallas
-- ---------------------------------------------------------------------
-- Lotes en venta (Pantalla 12)
CREATE VIEW v_lotes_en_venta AS
SELECT l.id AS lote_id, l.producto, l.variedad, l.cantidad_estimada, l.unidad,
       l.precio_sugerido, l.valor_estimado, c.nombre AS categoria,
       f.id AS finca_id, f.nombre_finca, f.nombre_productor,
       f.departamento, f.provincia, f.distrito,
       (SELECT url FROM lote_fotos lf WHERE lf.lote_id = l.id ORDER BY orden LIMIT 1) AS foto
FROM lotes l
JOIN fincas f        ON f.id = l.finca_id
LEFT JOIN categorias c ON c.id = l.categoria_id
WHERE l.estado = 'activo';

-- Perfil del productor con edad (Pantallas 13 y 14)
CREATE VIEW v_perfil_productor AS
SELECT u.id AS agricultor_id, u.nombres, u.apellidos,
       DATE_PART('year', AGE(u.fecha_nacimiento))::INT AS edad,
       u.correo, u.telefono_whatsapp, u.foto_perfil_url,
       f.id AS finca_id, f.nombre_finca, f.departamento, f.provincia, f.distrito,
       f.latitud, f.longitud,
       (SELECT COUNT(*) FROM ventas v JOIN lotes l2 ON l2.id = v.lote_id
         WHERE l2.finca_id = f.id) AS total_ventas
FROM usuarios u
JOIN fincas f ON f.agricultor_id = u.id
WHERE u.tipo = 'agricultor';

-- Historial de ventas por finca (Pantalla 13)
CREATE VIEW v_historial_ventas AS
SELECT f.id AS finca_id, l.producto, v.cantidad_vendida, l.unidad, v.precio_final, v.fecha_venta
FROM ventas v
JOIN lotes  l ON l.id = v.lote_id
JOIN fincas f ON f.id = l.finca_id
ORDER BY v.fecha_venta DESC;

-- ---------------------------------------------------------------------
-- Datos iniciales de catálogos
-- ---------------------------------------------------------------------
INSERT INTO categorias (nombre) VALUES
 ('Tubérculos'), ('Frutas'), ('Hortalizas'), ('Granos y cereales'), ('Café y cacao'), ('Orgánicos');

INSERT INTO certificaciones (nombre) VALUES
 ('Orgánico'), ('Comercio justo'), ('GlobalG.A.P.');
