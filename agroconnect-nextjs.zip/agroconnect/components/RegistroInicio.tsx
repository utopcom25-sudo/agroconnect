"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import type { FormEvent } from "react";
import type { TipoUsuario } from "@/lib/types";
import { Header } from "./Header";
import { Badge, Button, Card, Divider, GoogleButton, TextField } from "./ui";

/** Pantalla "Crear cuenta" con opción de Google (agricultor y comprador persona) */
export function RegistroInicio({ tipo, badge, subtitulo, back, next }: { tipo: TipoUsuario; badge: string; subtitulo: string; back: string; next: string }) {
  const router = useRouter();
  const [correo, setCorreo] = useState("");

  const handleGoogle = () => {
    console.log("[AgroConnect] Continuar con Google:", { tipo });
    // SUPABASE (siguiente paso):
    // await supabase.auth.signInWithOAuth({ provider: "google", options: { redirectTo: `${location.origin}${next}` } });
    router.push(next);
  };

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    console.log("[AgroConnect] Registro con correo:", { tipo, correo });
    router.push(`${next}?correo=${encodeURIComponent(correo)}`);
  };

  return (
    <>
      <Header back={{ href: back }} />
      <main className="mx-auto max-w-[480px] px-6 pb-20 pt-16">
        <Card className="flex flex-col gap-5">
          <Badge>{badge}</Badge>
          <h1 className="font-display text-3xl font-bold text-bosque">Crea tu cuenta</h1>
          <p className="text-[15px] leading-relaxed text-musgo">{subtitulo}</p>
          <GoogleButton onClick={handleGoogle} />
          <Divider>o con tu correo</Divider>
          <form onSubmit={handleSubmit} className="flex flex-col gap-5">
            <TextField label="Correo electrónico" type="email" required value={correo} onChange={setCorreo} placeholder="tucorreo@ejemplo.com" autoComplete="email" />
            <Button type="submit">Continuar</Button>
          </form>
          <p className="text-center text-sm text-musgo">
            ¿Ya tienes cuenta? <Link href="#" className="font-semibold text-hoja">Inicia sesión</Link>
          </p>
        </Card>
        <p className="mt-5 text-center text-xs text-musgo">Al continuar aceptas los Términos y la Política de privacidad de AgroConnect.</p>
      </main>
    </>
  );
}
