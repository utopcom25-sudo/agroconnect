"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import type { LoteEnVenta } from "@/lib/types";
import { IconChat, IconMail, IconPhone } from "./icons";
import { Button, Modal } from "./ui";

/** Botones "Estoy interesado" y "Volver" + ventana de contacto con el productor */
export function AccionesLote({ lote }: { lote: LoteEnVenta }) {
  const router = useRouter();
  const [abierto, setAbierto] = useState(false);
  const p = lote.productor;
  const nombre = `${p.nombres} ${p.apellidos}`;
  const mensaje = `Hola ${p.nombres}, me interesa tu lote de ${lote.producto.toLowerCase()} publicado en AgroConnect.`;

  // wa.me abre directamente la app de WhatsApp en el celular (y WhatsApp Web en PC)
  const wspHref = `https://wa.me/${p.telefono_whatsapp}?text=${encodeURIComponent(mensaje)}`;
  const telHref = `tel:+${p.telefono_whatsapp}`;
  const mailHref = `mailto:${p.correo}?subject=${encodeURIComponent(`Lote de ${lote.producto} – AgroConnect`)}&body=${encodeURIComponent(mensaje)}`;
  const telVisible = `+${p.telefono_whatsapp.replace(/^(\d{2})(\d{3})(\d{3})(\d{3})$/, "$1 $2 $3 $4")}`;

  const registrarContacto = (canal: "whatsapp" | "llamada" | "correo") => {
    console.log("[AgroConnect] Contacto → contactos:", { lote_id: lote.id, canal });
    // SUPABASE (siguiente paso):
    // await supabase.from("contactos").insert({ lote_id: lote.id, comprador_id: user.id, canal });
  };

  const opcion = "flex min-h-16 items-center gap-3.5 rounded-2xl px-5 text-left transition";

  return (
    <>
      <div className="flex flex-wrap justify-center gap-4">
        <Button className="h-15 min-w-64 text-[17px]" onClick={() => setAbierto(true)}>Estoy interesado</Button>
        <Button variant="outline" className="h-15 min-w-44 text-[17px]" onClick={() => (window.history.length > 1 ? router.back() : router.push("/lotes"))}>Volver</Button>
      </div>

      <Modal open={abierto} onClose={() => setAbierto(false)} title={nombre} subtitle={`${lote.finca.nombre_finca} · ${lote.producto}`} maxWidth="max-w-[480px]">
        <div className="flex flex-col gap-3 px-8 pb-8 pt-6">
          <p className="mb-1 text-[15px] text-musgo">Elige cómo quieres contactar al productor:</p>
          <a href={wspHref} target="_blank" rel="noopener noreferrer" onClick={() => registrarContacto("whatsapp")} className={`${opcion} bg-hoja text-white hover:bg-hoja-oscuro`}>
            <IconChat className="h-6 w-6 shrink-0" />
            <span className="flex flex-col">
              <span className="font-semibold">Escribir por WhatsApp</span>
              <span className="text-sm text-menta">{telVisible}</span>
            </span>
          </a>
          <a href={telHref} onClick={() => registrarContacto("llamada")} className={`${opcion} border-2 border-hoja bg-white text-bosque hover:bg-brote`}>
            <IconPhone className="h-6 w-6 shrink-0 text-hoja" />
            <span className="flex flex-col">
              <span className="font-semibold">Llamar al productor</span>
              <span className="text-sm text-musgo">{telVisible}</span>
            </span>
          </a>
          <a href={mailHref} onClick={() => registrarContacto("correo")} className={`${opcion} border border-borde bg-brote text-bosque hover:border-hoja`}>
            <IconMail className="h-6 w-6 shrink-0 text-hoja" />
            <span className="flex flex-col">
              <span className="font-semibold">Enviar correo electrónico</span>
              <span className="text-sm text-musgo">{p.correo}</span>
            </span>
          </a>
        </div>
      </Modal>
    </>
  );
}
