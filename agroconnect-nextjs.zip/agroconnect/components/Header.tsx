import Link from "next/link";
import { IconLeaf } from "./icons";

interface NavLink {
  href: string;
  label: string;
  active?: boolean;
}

export function Header({ links = [], back }: { links?: NavLink[]; back?: { href: string; label?: string } }) {
  return (
    <header className="bg-bosque px-6">
      <div className="mx-auto flex min-h-[72px] max-w-6xl flex-wrap items-center justify-between gap-4">
        <Link href="/" className="flex items-center gap-2.5 font-display text-[22px] font-bold text-white">
          <IconLeaf className="h-7 w-7 text-lima" />
          AgroConnect
        </Link>
        <nav aria-label="Principal" className="flex flex-wrap items-center gap-6">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              aria-current={l.active ? "page" : undefined}
              className={
                l.active
                  ? "border-b-2 border-lima pb-1 font-semibold text-white"
                  : "font-medium text-menta hover:text-white"
              }
            >
              {l.label}
            </Link>
          ))}
          {back && (
            <Link href={back.href} className="font-medium text-menta hover:text-white">
              ← {back.label ?? "Atrás"}
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
}
