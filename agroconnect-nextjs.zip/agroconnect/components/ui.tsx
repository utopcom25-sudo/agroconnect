"use client";

import Link from "next/link";
import { useEffect, useId, useState } from "react";
import type { ComponentProps, ReactNode } from "react";
import { IconCamera, IconUpload, IconX } from "./icons";

/* ---------- Estilos base ---------- */
export const inputCls =
  "h-12 w-full rounded-[10px] border border-linea bg-white px-3.5 text-[15px] text-tinta placeholder:text-musgo/70 focus:border-hoja focus:outline-2 focus:outline-offset-1 focus:outline-hoja";

const btn = {
  primary: "bg-hoja text-white hover:bg-hoja-oscuro",
  outline: "border border-linea bg-white text-tinta hover:border-hoja",
  ghost: "border border-hoja text-hoja hover:bg-brote",
};
const btnBase =
  "inline-flex h-13 items-center justify-center gap-2.5 rounded-xl px-7 text-base font-semibold transition disabled:cursor-not-allowed disabled:opacity-60";

export function Button({
  variant = "primary",
  className = "",
  ...props
}: ComponentProps<"button"> & { variant?: keyof typeof btn }) {
  return <button className={`${btnBase} ${btn[variant]} ${className}`} {...props} />;
}

export function ButtonLink({
  variant = "primary",
  className = "",
  ...props
}: ComponentProps<typeof Link> & { variant?: keyof typeof btn }) {
  return <Link className={`${btnBase} ${btn[variant]} ${className}`} {...props} />;
}

/* ---------- Campos ---------- */
export function Field({ label, children, className = "", hint }: { label: string; children: (id: string) => ReactNode; className?: string; hint?: string }) {
  const id = useId();
  return (
    <div className={`flex flex-col gap-1.5 ${className}`}>
      <label htmlFor={id} className="text-sm font-semibold">{label}</label>
      {children(id)}
      {hint && <span className="text-xs text-musgo">{hint}</span>}
    </div>
  );
}

export function TextField({
  label, value, onChange, className, hint, ...rest
}: Omit<ComponentProps<"input">, "onChange" | "value"> & { label: string; value: string; onChange: (v: string) => void; hint?: string }) {
  return (
    <Field label={label} className={className} hint={hint}>
      {(id) => <input id={id} className={inputCls} value={value} onChange={(e) => onChange(e.target.value)} {...rest} />}
    </Field>
  );
}

export function SelectField({
  label, value, onChange, options, placeholder, className, required,
}: {
  label: string; value: string; onChange: (v: string) => void;
  options: (string | { value: string; label: string })[];
  placeholder?: string; className?: string; required?: boolean;
}) {
  return (
    <Field label={label} className={className}>
      {(id) => (
        <select id={id} className={inputCls} value={value} onChange={(e) => onChange(e.target.value)} required={required}>
          {placeholder && <option value="">{placeholder}</option>}
          {options.map((o) => {
            const opt = typeof o === "string" ? { value: o, label: o } : o;
            return <option key={opt.value} value={opt.value}>{opt.label}</option>;
          })}
        </select>
      )}
    </Field>
  );
}

export function TextArea({ label, value, onChange, placeholder, className }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string; className?: string }) {
  return (
    <Field label={label} className={className}>
      {(id) => (
        <textarea id={id} rows={3} className={`${inputCls} h-auto resize-y py-3`} value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} />
      )}
    </Field>
  );
}

/** Chips seleccionables (checkbox) para preferencias y certificaciones */
export function ChipGroup({ legend, options, selected, onToggle }: { legend: string; options: string[]; selected: string[]; onToggle: (v: string) => void }) {
  return (
    <fieldset className="flex flex-col gap-3">
      <legend className="mb-3 text-sm font-semibold">{legend}</legend>
      <div className="flex flex-wrap gap-2.5">
        {options.map((o) => {
          const on = selected.includes(o);
          return (
            <label key={o} className={`flex min-h-11 cursor-pointer items-center gap-2 rounded-full border px-4 text-[15px] transition ${on ? "border-hoja bg-brote font-semibold text-bosque" : "border-linea bg-white"}`}>
              <input type="checkbox" className="h-[18px] w-[18px] accent-hoja" checked={on} onChange={() => onToggle(o)} />
              {o}
            </label>
          );
        })}
      </div>
    </fieldset>
  );
}

/** Foto de perfil con vista previa */
export function PhotoUpload({ value, onChange, label = "Foto de perfil" }: { value: File | null; onChange: (f: File | null) => void; label?: string }) {
  const id = useId();
  const [preview, setPreview] = useState<string | null>(null);
  useEffect(() => {
    if (!value) return setPreview(null);
    const url = URL.createObjectURL(value);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [value]);

  return (
    <div className="flex flex-wrap items-center gap-5">
      <div className="flex h-24 w-24 items-center justify-center overflow-hidden rounded-full border-2 border-dashed border-hoja bg-menta">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        {preview ? <img src={preview} alt="Vista previa de la foto" className="h-full w-full object-cover" /> : <IconCamera className="h-9 w-9 text-hoja" />}
      </div>
      <div className="flex flex-col gap-2">
        <span className="text-sm font-semibold">{label}</span>
        <label htmlFor={id} className="cursor-pointer self-start rounded-[10px] border border-hoja px-4 py-2.5 text-sm font-semibold text-hoja hover:bg-brote">
          {value ? "Cambiar foto" : "Adjuntar foto"}
        </label>
        <input id={id} type="file" accept="image/*" className="sr-only" onChange={(e) => onChange(e.target.files?.[0] ?? null)} />
        <span className="text-xs text-musgo">{value ? value.name : "JPG o PNG, máximo 5 MB"}</span>
      </div>
    </div>
  );
}

/** Subida de varias fotos (lote de cosecha) */
export function MultiPhotoUpload({ files, onChange }: { files: File[]; onChange: (f: File[]) => void }) {
  const id = useId();
  return (
    <div className="flex flex-col gap-1.5">
      <span className="text-sm font-semibold">Fotos del lote</span>
      <label htmlFor={id} className="flex h-24 cursor-pointer items-center justify-center gap-2.5 rounded-xl border-2 border-dashed border-hoja bg-brote font-semibold text-bosque">
        <IconUpload className="h-5 w-5 text-hoja" />
        {files.length ? `${files.length} foto(s) seleccionada(s)` : "Subir hasta 6 fotos"}
      </label>
      <input id={id} type="file" accept="image/*" multiple className="sr-only" onChange={(e) => onChange(Array.from(e.target.files ?? []).slice(0, 6))} />
    </div>
  );
}

/* ---------- Layout ---------- */
export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`rounded-3xl border border-borde bg-white p-8 sm:p-10 ${className}`}>{children}</div>;
}

export function Badge({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <span className={`inline-flex self-start rounded-full bg-menta px-3 py-1.5 text-[13px] font-semibold text-bosque ${className}`}>{children}</span>;
}

export function Stepper({ step, total, label }: { step: number; total: number; label: string }) {
  return (
    <div className="mb-6 flex flex-col gap-2">
      <span className="text-[13px] font-semibold text-hoja">Paso {step} de {total} · {label}</span>
      <div className="grid gap-1.5" style={{ gridTemplateColumns: `repeat(${total}, minmax(0, 1fr))` }}>
        {Array.from({ length: total }, (_, i) => (
          <span key={i} className={`h-1.5 rounded ${i < step ? "bg-hoja" : "bg-borde"}`} />
        ))}
      </div>
    </div>
  );
}

export function Divider({ children }: { children: ReactNode }) {
  return (
    <div className="flex items-center gap-3 text-[13px] text-musgo">
      <span className="h-px flex-1 bg-borde" />{children}<span className="h-px flex-1 bg-borde" />
    </div>
  );
}

/** Botón "Continuar con Google". En el siguiente paso: supabase.auth.signInWithOAuth({ provider: "google" }) */
export function GoogleButton({ onClick }: { onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} className="flex h-13 items-center justify-center gap-3 rounded-xl border border-linea bg-white text-base font-semibold hover:border-hoja">
      <svg viewBox="0 0 48 48" className="h-5 w-5" aria-hidden>
        <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3 0 5.8 1.1 7.9 3l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z" />
        <path fill="#FF3D00" d="m6.3 14.7 6.6 4.8C14.7 15.1 19 12 24 12c3 0 5.8 1.1 7.9 3l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z" />
        <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z" />
        <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z" />
      </svg>
      Continuar con Google
    </button>
  );
}

/** Ventana modal accesible (cierra con Esc o clic fuera) */
export function Modal({ open, onClose, title, subtitle, children, maxWidth = "max-w-3xl" }: { open: boolean; onClose: () => void; title: string; subtitle?: string; children: ReactNode; maxWidth?: string }) {
  const titleId = useId();
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-bosque/80 px-4 py-10" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div role="dialog" aria-modal="true" aria-labelledby={titleId} className={`mx-auto w-full ${maxWidth} overflow-hidden rounded-3xl bg-white`}>
        <div className="flex items-start justify-between gap-4 px-8 pt-7">
          <div className="flex flex-col gap-1.5">
            {subtitle && <span className="text-[13px] font-semibold text-hoja">{subtitle}</span>}
            <h2 id={titleId} className="font-display text-3xl font-bold text-bosque">{title}</h2>
          </div>
          <button type="button" onClick={onClose} aria-label="Cerrar" className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-brote text-bosque hover:bg-menta">
            <IconX className="h-5 w-5" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}
