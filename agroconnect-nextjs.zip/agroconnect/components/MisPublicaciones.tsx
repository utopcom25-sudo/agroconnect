"use client";

import { useState } from "react";
import { MIS_PUBLICACIONES } from "@/lib/data";
import { soles, unidadCorta } from "@/lib/constants";
import type { Publicacion } from "@/lib/types";
import { IconHome, IconPlus } from "./icons";
import { ButtonLink } from "./ui";
import { OfrecerLoteModal } from "./forms/OfrecerLoteModal";

const ESTADOS: Record<Publicacion["estado"], { label: string; cls: string }> = {
  activo: { label: "Activo", cls: "bg-menta text-bosque" },
  pendiente_pago: { label: "Pendiente de pago", cls: "bg-amber-100 text-amber-900" },
  vendido: { label: "Vendido", cls: "bg-gray-100 text-gray-700" },
  vencido: { label: "Vencido", cls: "bg-gray-100 text-gray-700" },
};

export function MisPublicaciones() {
  const [abierto, setAbierto] = useState(false);
  // SUPABASE (siguiente paso): cargar con supabase.from("lotes").select("*").eq("finca_id", fincaId).order("creado_en", { ascending: false })
  const publicaciones = MIS_PUBLICACIONES;
  const finca = { nombre: "Finca Los Andes", productor: "Rosa Quispe Mamani", ubicacion: "Sapallanga, Huancayo – Junín", cultivo: "Papa" };

  return (
    <main className="mx-auto flex max-w-6xl flex-col gap-8 px-6 pb-20 pt-10">
      <section className="flex flex-wrap items-center gap-5 rounded-3xl border border-borde bg-white p-6">
        <div className="flex h-22 w-22 items-center justify-center rounded-2xl bg-menta"><IconHome className="h-10 w-10 text-hoja" /></div>
        <div className="flex min-w-[260px] flex-1 flex-col gap-1">
          <h1 className="font-display text-3xl font-bold text-bosque">{finca.nombre}</h1>
          <span className="text-[15px] text-musgo">{finca.productor} · {finca.ubicacion} · Cultivo principal: {finca.cultivo}</span>
        </div>
        <ButtonLink href="/agricultor/finca" variant="ghost">Editar perfil</ButtonLink>
      </section>

      <section className="flex flex-col gap-4">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <h2 className="font-display text-2xl font-semibold">Publicaciones anteriores</h2>
          <span className="text-sm text-musgo">{publicaciones.length} publicaciones</span>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {publicaciones.map((p) => (
            <article key={p.id} className="flex flex-col overflow-hidden rounded-2xl border border-borde bg-white">
              <div className="flex h-36 items-center justify-center bg-brote text-[13px] text-musgo">Foto del lote</div>
              <div className="flex flex-col gap-2 p-4">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="font-display text-lg font-semibold">{p.producto}</h3>
                  <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${ESTADOS[p.estado].cls}`}>{ESTADOS[p.estado].label}</span>
                </div>
                <span className="text-sm text-musgo">{p.cantidad_estimada.toLocaleString("es-PE")} {unidadCorta(p.unidad)} · {soles(p.precio_sugerido)} por {unidadCorta(p.unidad)}</span>
                <span className="text-[13px] text-musgo">Publicado el {p.fecha}</span>
              </div>
            </article>
          ))}
        </div>
      </section>

      <button
        type="button"
        onClick={() => setAbierto(true)}
        className="flex h-15 items-center gap-2.5 self-center rounded-full bg-hoja px-9 text-[17px] font-semibold text-white hover:bg-hoja-oscuro"
      >
        <IconPlus className="h-5 w-5" /> Publicar nueva publicación
      </button>

      <OfrecerLoteModal open={abierto} onClose={() => setAbierto(false)} nombreFinca={finca.nombre} />
    </main>
  );
}
