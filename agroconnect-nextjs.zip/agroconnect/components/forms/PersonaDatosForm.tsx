"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import type { FormEvent } from "react";
import { useForm } from "@/lib/useForm";
import { CATEGORIAS, FRECUENCIAS } from "@/lib/constants";
import type { CompradorPersonaForm } from "@/lib/types";
import { Button, Card, ChipGroup, PhotoUpload, SelectField, TextField } from "../ui";
import { DatosPersonalesFields, aFilaUsuario, datosPersonalesVacios, validarDatosPersonales } from "./DatosPersonalesFields";

export function PersonaDatosForm({ correoInicial = "" }: { correoInicial?: string }) {
  const router = useRouter();
  const { values: v, set, toggle } = useForm<CompradorPersonaForm>({
    ...datosPersonalesVacios(correoInicial),
    preferencias: [],
    frecuencia_compra: "Semanal",
    zona_entrega: "",
  });
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const err = validarDatosPersonales(v) ?? (v.preferencias.length ? null : "Elige al menos una preferencia de compra.");
    setError(err);
    if (err) return;

    const usuario = aFilaUsuario(v, "comprador_persona");
    const perfil = { frecuencia_compra: v.frecuencia_compra, zona_entrega: v.zona_entrega };
    console.log("[AgroConnect] Comprador persona →", { usuarios: usuario, perfiles_comprador: perfil, preferencias: v.preferencias, foto: v.foto_perfil });

    // SUPABASE (siguiente paso):
    // const { data } = await supabase.auth.signUp({ email: usuario.correo, password: v.password });
    // const id = data.user!.id;
    // await supabase.from("usuarios").insert({ id, ...usuario, proveedor: "email", foto_perfil_url });
    // await supabase.from("perfiles_comprador").insert({ usuario_id: id, ...perfil });
    // (preferencias: buscar ids en `categorias` e insertar en `preferencias_compra`)

    router.push("/lotes");
  };

  return (
    <Card>
      <form onSubmit={handleSubmit} className="flex flex-col gap-7">
        <div className="flex flex-col gap-1.5">
          <span className="text-[13px] font-semibold text-hoja">Comprador · Persona</span>
          <h1 className="font-display text-3xl font-bold text-bosque">Completa tu perfil</h1>
          <p className="text-[15px] text-musgo">Así los productores sabrán quién los contacta.</p>
        </div>

        <DatosPersonalesFields values={v} set={set} conFoto={false} />

        <div className="flex flex-col gap-5 border-t border-borde pt-6">
          <h2 className="font-display text-lg font-semibold">Preferencias de compra</h2>
          <ChipGroup legend="¿Qué productos te interesan?" options={CATEGORIAS} selected={v.preferencias} onToggle={(c) => toggle("preferencias", c)} />
          <div className="grid gap-5 sm:grid-cols-2">
            <SelectField label="Frecuencia de compra" value={v.frecuencia_compra} onChange={set("frecuencia_compra")} options={FRECUENCIAS} />
            <TextField label="Zona de entrega" value={v.zona_entrega} onChange={set("zona_entrega")} placeholder="Ej. Lima – San Juan de Lurigancho" />
          </div>
        </div>

        <div className="border-t border-borde pt-6">
          <PhotoUpload value={v.foto_perfil} onChange={set("foto_perfil")} />
        </div>

        {error && <p role="alert" className="rounded-lg bg-red-50 px-4 py-3 text-sm font-medium text-red-800">{error}</p>}
        <Button type="submit" className="h-14 text-[17px]">Crear perfil</Button>
      </form>
    </Card>
  );
}
