"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import type { FormEvent } from "react";
import { useForm } from "@/lib/useForm";
import { ButtonLink, Button, Card } from "../ui";
import { DatosPersonalesFields, aFilaUsuario, datosPersonalesVacios, validarDatosPersonales } from "./DatosPersonalesFields";

export function AgricultorDatosForm({ correoInicial = "" }: { correoInicial?: string }) {
  const router = useRouter();
  const { values, set } = useForm(datosPersonalesVacios(correoInicial));
  const [error, setError] = useState<string | null>(null);
  const [enviando, setEnviando] = useState(false);

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const err = validarDatosPersonales(values);
    setError(err);
    if (err) return;

    setEnviando(true);
    const fila = aFilaUsuario(values, "agricultor");
    console.log("[AgroConnect] Registro agricultor → usuarios:", fila, "foto:", values.foto_perfil);

    // SUPABASE (siguiente paso):
    // const { data, error } = await supabase.auth.signUp({ email: fila.correo, password: values.password });
    // const foto_perfil_url = values.foto_perfil ? await subirArchivo("fotos-perfil", values.foto_perfil) : null;
    // await supabase.from("usuarios").insert({ id: data.user!.id, ...fila, proveedor: "email", foto_perfil_url });

    setEnviando(false);
    router.push("/agricultor/finca");
  };

  return (
    <Card>
      <form onSubmit={handleSubmit} className="flex flex-col gap-6">
        <div className="flex flex-col gap-1.5">
          <h1 className="font-display text-3xl font-bold text-bosque">Cuéntanos sobre ti</h1>
          <p className="text-[15px] text-musgo">Estos datos aparecerán en tu perfil de productor.</p>
        </div>
        <DatosPersonalesFields values={values} set={set} />
        {error && <p role="alert" className="rounded-lg bg-red-50 px-4 py-3 text-sm font-medium text-red-800">{error}</p>}
        <div className="flex flex-wrap justify-between gap-3">
          <ButtonLink href="/agricultor/registro" variant="outline">Atrás</ButtonLink>
          <Button type="submit" disabled={enviando}>{enviando ? "Guardando…" : "Crear cuenta y continuar"}</Button>
        </div>
      </form>
    </Card>
  );
}
