"use client";

import type { DatosPersonalesForm } from "@/lib/types";
import { PhotoUpload, TextField } from "../ui";

export const datosPersonalesVacios = (correo = ""): DatosPersonalesForm => ({
  nombres: "", apellidos: "", fecha_nacimiento: "", correo, usuario: "",
  telefono_whatsapp: "", password: "", confirmar_password: "", foto_perfil: null,
});

/** Validación simple antes de enviar. Devuelve un mensaje de error o null. */
export function validarDatosPersonales(v: DatosPersonalesForm): string | null {
  if (v.password.length < 8) return "La contraseña debe tener al menos 8 caracteres.";
  if (v.password !== v.confirmar_password) return "Las contraseñas no coinciden.";
  return null;
}

/** Campos compartidos: nombres, apellidos, nacimiento, correo, usuario, celular, contraseña */
export function DatosPersonalesFields<T extends DatosPersonalesForm>({
  values, set, conFoto = true,
}: {
  values: T;
  set: <K extends keyof T>(k: K) => (v: T[K]) => void;
  /** false = la foto se coloca aparte (p. ej. al final del formulario) */
  conFoto?: boolean;
}) {
  const s = (k: keyof DatosPersonalesForm) => set(k as keyof T) as unknown as (v: string) => void;

  return (
    <>
      {conFoto && <PhotoUpload value={values.foto_perfil} onChange={set("foto_perfil") as (f: File | null) => void} />}
      <div className="grid gap-5 sm:grid-cols-2">
        <TextField label="Nombres" required value={values.nombres} onChange={s("nombres")} placeholder="Ej. Rosa María" autoComplete="given-name" />
        <TextField label="Apellidos" required value={values.apellidos} onChange={s("apellidos")} placeholder="Ej. Quispe Mamani" autoComplete="family-name" />
        <TextField label="Fecha de nacimiento" type="date" required value={values.fecha_nacimiento} onChange={s("fecha_nacimiento")} />
        <TextField label="Correo electrónico" type="email" required value={values.correo} onChange={s("correo")} placeholder="tucorreo@ejemplo.com" autoComplete="email" />
        <TextField label="Usuario" required value={values.usuario} onChange={s("usuario")} placeholder="@tuusuario" autoComplete="username" />
        <TextField label="Celular (WhatsApp)" type="tel" value={values.telefono_whatsapp} onChange={s("telefono_whatsapp")} placeholder="+51 9__ ___ ___" autoComplete="tel" />
        <TextField label="Contraseña" type="password" required minLength={8} value={values.password} onChange={s("password")} placeholder="Mínimo 8 caracteres" autoComplete="new-password" />
        <TextField label="Confirmar contraseña" type="password" required value={values.confirmar_password} onChange={s("confirmar_password")} placeholder="Repite tu contraseña" autoComplete="new-password" />
      </div>
    </>
  );
}

/** Convierte el formulario en la fila de la tabla `usuarios` (sin password ni archivo) */
export function aFilaUsuario(v: DatosPersonalesForm, tipo: "agricultor" | "comprador_persona") {
  return {
    tipo,
    nombres: v.nombres.trim(),
    apellidos: v.apellidos.trim(),
    fecha_nacimiento: v.fecha_nacimiento || null,
    correo: v.correo.trim().toLowerCase(),
    usuario: v.usuario.replace(/^@/, "").trim(),
    telefono_whatsapp: v.telefono_whatsapp.replace(/\D/g, "") || null,
  };
}
