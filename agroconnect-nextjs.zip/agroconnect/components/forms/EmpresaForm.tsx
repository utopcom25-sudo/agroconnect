"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import type { FormEvent } from "react";
import { useForm } from "@/lib/useForm";
import { CATEGORIAS, VOLUMENES } from "@/lib/constants";
import type { EmpresaForm as EmpresaT } from "@/lib/types";
import { IconX } from "../icons";
import { Button, ChipGroup, SelectField, TextArea, TextField } from "../ui";

export function EmpresaForm() {
  const router = useRouter();
  const { values: v, set, toggle } = useForm<EmpresaT>({
    nombre_comercial: "", ruc: "", preferencias: [], volumen_mensual: VOLUMENES[0], detalle_busqueda: "",
  });
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!v.preferencias.length) return setError("Elige al menos una preferencia de compra.");
    setError(null);

    const { preferencias, ...fila } = v;
    console.log("[AgroConnect] Comprador empresa → empresas:", { ...fila, ruc: v.ruc.trim() }, "preferencias:", preferencias);

    // SUPABASE (siguiente paso):
    // const { data: { user } } = await supabase.auth.getUser();
    // await supabase.from("empresas").insert({ usuario_id: user!.id, ...fila });
    // (preferencias: insertar en `preferencias_compra`)

    router.push("/lotes");
  };

  return (
    <div role="dialog" aria-labelledby="titulo-empresa" className="mx-auto max-w-[560px] rounded-3xl bg-white p-8 sm:p-9">
      <form onSubmit={handleSubmit} className="flex flex-col gap-5">
        <div className="flex items-start justify-between gap-4">
          <div className="flex flex-col gap-1.5">
            <span className="text-[13px] font-semibold text-hoja">Comprador · Empresa</span>
            <h1 id="titulo-empresa" className="font-display text-3xl font-bold text-bosque">Datos de tu empresa</h1>
          </div>
          <Link href="/comprador" aria-label="Cerrar" className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-brote text-bosque hover:bg-menta">
            <IconX className="h-5 w-5" />
          </Link>
        </div>

        <TextField label="Nombre comercial" required value={v.nombre_comercial} onChange={set("nombre_comercial")} placeholder="Ej. Distribuidora Valle Fresco" autoComplete="organization" />
        <TextField label="RUC o registro fiscal" required value={v.ruc} onChange={set("ruc")} placeholder="RUC de 11 dígitos o registro fiscal" hint="En Perú: RUC de 11 dígitos." />
        <ChipGroup legend="Preferencias de compra" options={CATEGORIAS} selected={v.preferencias} onToggle={(c) => toggle("preferencias", c)} />
        <SelectField label="Volumen mensual estimado" value={v.volumen_mensual} onChange={set("volumen_mensual")} options={VOLUMENES} />
        <TextArea label="Detalle de lo que buscas" value={v.detalle_busqueda} onChange={set("detalle_busqueda")} placeholder="Calibre, certificaciones, zona de recojo…" />

        {error && <p role="alert" className="rounded-lg bg-red-50 px-4 py-3 text-sm font-medium text-red-800">{error}</p>}
        <Button type="submit" className="h-14 text-[17px]">Guardar e ingresar</Button>
      </form>
    </div>
  );
}
