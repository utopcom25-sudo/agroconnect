"use client";

import Image from "next/image";
import { useRouter } from "next/navigation";
import type { FormEvent } from "react";
import { useForm } from "@/lib/useForm";
import { COMISION_PORCENTAJE, COMISION_PUBLICACION, YAPE, soles } from "@/lib/constants";
import type { PagoYapeForm as PagoT } from "@/lib/types";
import { Button, Field, PhotoUpload, TextField, inputCls } from "../ui";

export function PagoYapeForm({ montoInicial, producto, detalle }: { montoInicial: string; producto?: string; detalle?: string }) {
  const router = useRouter();
  const { values: v, set } = useForm<PagoT>({ monto_base: montoInicial, numero_operacion: "", captura: null });

  const base = Number(v.monto_base) || 0;
  const aPagar = Math.round(base * COMISION_PUBLICACION * 100) / 100;

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fila = {
      monto_base: base,
      porcentaje: COMISION_PORCENTAJE,
      metodo: "yape",
      numero_operacion: v.numero_operacion.trim(),
      estado: "pendiente" as const,
    };
    console.log("[AgroConnect] Pago Yape → pagos_publicacion:", fila, "monto a pagar:", aPagar, "captura:", v.captura);

    // SUPABASE (siguiente paso):
    // const captura_url = v.captura ? await subirArchivo("capturas-yape", v.captura) : null;
    // await supabase.from("pagos_publicacion").insert({ ...fila, lote_id, captura_url });

    router.push("/agricultor/publicaciones");
  };

  return (
    <div className="flex flex-wrap gap-6">
      <section className="flex min-w-[320px] flex-1 flex-col items-center gap-4 rounded-3xl border border-borde bg-white p-8 text-center">
        <h1 className="font-display text-2xl font-bold text-bosque">Paga con Yape</h1>
        <p className="text-[15px] text-musgo">Escanea el código desde tu app Yape.</p>
        <div className="rounded-2xl border-2 border-hoja bg-white p-4">
          {YAPE.qrSrc ? (
            <Image src={YAPE.qrSrc} alt="Código QR de Yape de AgroConnect" width={220} height={220} />
          ) : (
            <QrMuestra />
          )}
        </div>
        <div className="flex flex-col gap-0.5">
          <span className="text-sm text-musgo">Titular</span>
          <span className="font-semibold">AgroConnect {YAPE.titular}</span>
          <span className="text-[15px] text-musgo">Yape: {YAPE.numero}</span>
        </div>
      </section>

      <form onSubmit={handleSubmit} className="flex min-w-[340px] flex-1 flex-col gap-5 rounded-3xl border border-borde bg-white p-8">
        <h2 className="font-display text-xl font-semibold">Resumen del pago</h2>
        <Field label="Valor estimado del lote (S/)" hint={producto ? `${producto}${detalle ? ` · ${detalle}` : ""}` : undefined}>
          {(id) => (
            <input id={id} className={inputCls} type="number" min={0} step={0.01} required value={v.monto_base} onChange={(e) => set("monto_base")(e.target.value)} />
          )}
        </Field>
        <div className="flex justify-between text-[15px]"><span className="text-musgo">Porcentaje de la tarifa</span><span className="font-semibold">{COMISION_PORCENTAJE}%</span></div>
        <div className="flex flex-col gap-1 rounded-2xl bg-bosque p-5 text-white">
          <span className="text-sm text-menta">Monto a transferir por Yape</span>
          <span className="font-display text-4xl font-bold" aria-live="polite">{soles(aPagar)}</span>
        </div>
        <TextField label="N° de operación Yape" required value={v.numero_operacion} onChange={set("numero_operacion")} placeholder="Ej. 01234567" inputMode="numeric" />
        <PhotoUpload label="Captura del pago (opcional)" value={v.captura} onChange={set("captura")} />
        <Button type="submit">Ya pagué, publicar mi lote</Button>
        <p className="text-[13px] text-musgo">Tu lote se publicará cuando validemos el pago.</p>
      </form>
    </div>
  );
}

/** QR de muestra: reemplázalo poniendo tu QR real en /public y su ruta en YAPE.qrSrc */
function QrMuestra() {
  const cells: [number, number][] = [
    [8, 0], [10, 1], [12, 0], [14, 2], [9, 3], [11, 4], [15, 4], [0, 8], [3, 9], [8, 8], [12, 7], [14, 8], [19, 8], [22, 9],
    [1, 11], [4, 12], [7, 11], [11, 12], [12, 13], [15, 11], [17, 12], [22, 12], [0, 15], [5, 14], [8, 15], [16, 15], [20, 15],
    [24, 16], [9, 18], [11, 17], [14, 18], [12, 20], [8, 23], [15, 21], [23, 23], [18, 19], [20, 21], [10, 10], [13, 16],
  ];
  const finder = (x: number, y: number) => (
    <g key={`${x}-${y}`}>
      <rect x={x} y={y} width={7} height={7} fill="#0f3d2e" />
      <rect x={x + 1} y={y + 1} width={5} height={5} fill="#fff" />
      <rect x={x + 2} y={y + 2} width={3} height={3} fill="#0f3d2e" />
    </g>
  );
  return (
    <svg width={220} height={220} viewBox="0 0 25 25" shapeRendering="crispEdges" role="img" aria-label="Código QR de muestra (reemplazar por el QR real de Yape)">
      <rect width={25} height={25} fill="#fff" />
      {finder(0, 0)}{finder(18, 0)}{finder(0, 18)}
      {cells.map(([x, y]) => <rect key={`${x}-${y}`} x={x} y={y} width={1} height={1} fill="#0f3d2e" />)}
    </svg>
  );
}
