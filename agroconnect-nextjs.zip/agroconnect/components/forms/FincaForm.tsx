"use client";

import { useRouter } from "next/navigation";
import type { FormEvent } from "react";
import { useForm } from "@/lib/useForm";
import { CERTIFICACIONES, CULTIVOS, DEPARTAMENTOS, RIEGOS } from "@/lib/constants";
import type { FincaForm as FincaFormT, TipoRiego } from "@/lib/types";
import { IconPin } from "../icons";
import { Button, ButtonLink, Card, ChipGroup, SelectField, TextArea, TextField } from "../ui";

const vacio: FincaFormT = {
  nombre_finca: "", nombre_productor: "", cultivo_principal: "", otros_cultivos: "", area_hectareas: "",
  riego: "", departamento: "", provincia: "", distrito: "", direccion_referencia: "", certificaciones: [], descripcion: "",
};

export function FincaForm() {
  const router = useRouter();
  const { values: v, set, toggle } = useForm(vacio);

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const { certificaciones, ...resto } = v;
    const fila = {
      ...resto,
      area_hectareas: v.area_hectareas ? Number(v.area_hectareas) : null,
      riego: v.riego || null,
    };
    console.log("[AgroConnect] Perfil de chacra → fincas:", fila, "certificaciones:", certificaciones);

    // SUPABASE (siguiente paso):
    // const { data: { user } } = await supabase.auth.getUser();
    // const { data: finca } = await supabase.from("fincas").insert({ ...fila, agricultor_id: user!.id }).select().single();
    // (luego insertar en finca_certificaciones con finca.id)

    router.push("/agricultor/publicaciones");
  };

  return (
    <Card>
      <form onSubmit={handleSubmit} className="flex flex-col gap-8">
        <div className="flex flex-col gap-1.5">
          <h1 className="font-display text-3xl font-bold text-bosque">Crea el perfil de tu chacra / finca</h1>
          <p className="text-[15px] text-musgo">Los compradores verán esta información en cada lote que publiques.</p>
        </div>

        <fieldset className="grid gap-5 sm:grid-cols-2">
          <legend className="mb-4 font-display text-lg font-semibold">Datos generales</legend>
          <TextField label="Nombre de la chacra / finca" required value={v.nombre_finca} onChange={set("nombre_finca")} placeholder="Ej. Finca Los Andes" />
          <TextField label="Nombre del productor" required value={v.nombre_productor} onChange={set("nombre_productor")} placeholder="Ej. Rosa Quispe Mamani" />
          <SelectField label="Cultivo principal" required value={v.cultivo_principal} onChange={set("cultivo_principal")} options={CULTIVOS} placeholder="Selecciona un cultivo" />
          <TextField label="Otros cultivos" value={v.otros_cultivos} onChange={set("otros_cultivos")} placeholder="Ej. haba, olluco, oca" />
          <TextField label="Área cultivable (hectáreas)" type="number" min={0} step={0.1} value={v.area_hectareas} onChange={set("area_hectareas")} placeholder="Ej. 3.5" />
          <SelectField label="Tipo de riego" value={v.riego} onChange={(x) => set("riego")(x as TipoRiego | "")} options={RIEGOS} placeholder="Selecciona" />
        </fieldset>

        <fieldset className="grid gap-5 sm:grid-cols-3">
          <legend className="mb-4 font-display text-lg font-semibold">Ubicación de la chacra</legend>
          <SelectField label="Departamento" required value={v.departamento} onChange={set("departamento")} options={DEPARTAMENTOS} placeholder="Selecciona" />
          <TextField label="Provincia" required value={v.provincia} onChange={set("provincia")} placeholder="Ej. Huancayo" />
          <TextField label="Distrito" value={v.distrito} onChange={set("distrito")} placeholder="Ej. Sapallanga" />
          <TextField className="sm:col-span-3" label="Dirección o referencia" value={v.direccion_referencia} onChange={set("direccion_referencia")} placeholder="Ej. Km 12 carretera central, frente al colegio" />
          {/* Aquí puedes integrar un mapa (Google Maps / Leaflet) para guardar latitud y longitud */}
          <div className="flex h-44 items-center justify-center gap-2.5 rounded-2xl border border-borde bg-brote text-sm font-medium text-musgo sm:col-span-3">
            <IconPin className="h-5 w-5 text-hoja" /> Mapa: marca la ubicación de tu parcela
          </div>
        </fieldset>

        <div className="flex flex-col gap-5">
          <ChipGroup legend="Certificaciones" options={CERTIFICACIONES} selected={v.certificaciones} onToggle={(c) => toggle("certificaciones", c)} />
          <TextArea label="Descripción de la chacra" value={v.descripcion} onChange={set("descripcion")} placeholder="Cuenta cómo cultivas, altitud, temporada de cosecha…" />
        </div>

        <div className="flex flex-wrap justify-between gap-3">
          <ButtonLink href="/agricultor/datos" variant="outline">Atrás</ButtonLink>
          <Button type="submit">Guardar perfil de chacra</Button>
        </div>
      </form>
    </Card>
  );
}
