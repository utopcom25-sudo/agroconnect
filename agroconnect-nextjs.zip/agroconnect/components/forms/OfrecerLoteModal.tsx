"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import type { FormEvent } from "react";
import { useForm } from "@/lib/useForm";
import { CALIDADES, COMISION_PUBLICACION, ENTREGAS, UNIDADES, soles, unidadCorta } from "@/lib/constants";
import type { FormaEntrega, LoteForm, Unidad } from "@/lib/types";
import { Button, Modal, MultiPhotoUpload, SelectField, TextArea, TextField } from "../ui";

const vacio: LoteForm = {
  producto: "", variedad: "", cantidad_estimada: "", unidad: "kg", precio_sugerido: "",
  calidad: "Primera", disponible_desde: "", entrega: "recojo_chacra", comentarios: "", fotos: [],
};

type Tab = "datos" | "extra";

export function OfrecerLoteModal({ open, onClose, nombreFinca }: { open: boolean; onClose: () => void; nombreFinca: string }) {
  const router = useRouter();
  const { values: v, set } = useForm(vacio);
  const [tab, setTab] = useState<Tab>("datos");

  const total = (Number(v.cantidad_estimada) || 0) * (Number(v.precio_sugerido) || 0);
  const comision = total * COMISION_PUBLICACION;

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // Si faltan datos obligatorios, vuelve a la primera pestaña
    if (!v.producto || !v.cantidad_estimada || !v.precio_sugerido) {
      setTab("datos");
      return;
    }
    const { fotos, ...resto } = v;
    const fila = {
      ...resto,
      cantidad_estimada: Number(v.cantidad_estimada),
      precio_sugerido: Number(v.precio_sugerido),
      disponible_desde: v.disponible_desde || null,
      estado: "pendiente_pago" as const,
    };
    console.log("[AgroConnect] Nuevo lote → lotes:", fila, "fotos:", fotos);

    // SUPABASE (siguiente paso):
    // const { data: lote } = await supabase.from("lotes").insert({ ...fila, finca_id }).select().single();
    // for (const [i, f] of fotos.entries()) {
    //   const url = await subirArchivo("fotos-lotes", f, `${lote.id}/`);
    //   await supabase.from("lote_fotos").insert({ lote_id: lote.id, url, orden: i });
    // }

    const q = new URLSearchParams({
      monto: total.toFixed(2),
      producto: v.producto,
      detalle: `${v.cantidad_estimada} ${unidadCorta(v.unidad)} × ${soles(Number(v.precio_sugerido))}`,
      // lote: lote.id  ← en el siguiente paso
    });
    router.push(`/agricultor/pago?${q.toString()}`);
  };

  const tabCls = (t: Tab) =>
    `h-12 border-b-[3px] px-4 text-[15px] font-semibold ${tab === t ? "border-hoja text-bosque" : "border-transparent text-musgo hover:text-bosque"}`;

  return (
    <Modal open={open} onClose={onClose} title="Ofrecer lote de cosecha" subtitle={`${nombreFinca} · Nueva publicación`}>
      <form onSubmit={handleSubmit}>
        <div role="tablist" className="mt-5 flex gap-2 border-b border-borde px-8">
          <button type="button" role="tab" aria-selected={tab === "datos"} className={tabCls("datos")} onClick={() => setTab("datos")}>Datos del lote</button>
          <button type="button" role="tab" aria-selected={tab === "extra"} className={tabCls("extra")} onClick={() => setTab("extra")}>Detalles extra</button>
        </div>

        <div className="flex flex-col gap-5 px-8 py-7">
          {/* Se ocultan con `hidden` (no se desmontan) para conservar lo escrito */}
          <div role="tabpanel" hidden={tab !== "datos"} className="grid gap-5 sm:grid-cols-2">
            <TextField label="Producto" required value={v.producto} onChange={set("producto")} placeholder="Ej. Papa amarilla" />
            <TextField label="Variedad" value={v.variedad} onChange={set("variedad")} placeholder="Ej. Tumbay" />
            <TextField label="Cantidad estimada" type="number" min={0} step="any" required value={v.cantidad_estimada} onChange={set("cantidad_estimada")} placeholder="Ej. 2000" />
            <SelectField label="Unidad" value={v.unidad} onChange={(x) => set("unidad")(x as Unidad)} options={UNIDADES} />
            <TextField className="sm:col-span-2" label="Precio sugerido por unidad (S/)" type="number" min={0} step={0.01} required value={v.precio_sugerido} onChange={set("precio_sugerido")} placeholder="Ej. 2.80" />
          </div>

          <div role="tabpanel" hidden={tab !== "extra"} className="grid gap-5 sm:grid-cols-2">
            <SelectField label="Calidad / categoría" value={v.calidad} onChange={set("calidad")} options={CALIDADES} />
            <TextField label="Disponible desde" type="date" value={v.disponible_desde} onChange={set("disponible_desde")} />
            <fieldset className="flex flex-col gap-2 sm:col-span-2">
              <legend className="mb-2 text-sm font-semibold">Forma de entrega</legend>
              <div className="flex flex-wrap gap-5">
                {ENTREGAS.map((o) => (
                  <label key={o.value} className="flex min-h-11 items-center gap-2">
                    <input type="radio" name="entrega" className="h-5 w-5 accent-hoja" checked={v.entrega === o.value} onChange={() => set("entrega")(o.value as FormaEntrega)} />
                    {o.label}
                  </label>
                ))}
              </div>
            </fieldset>
            <div className="sm:col-span-2"><MultiPhotoUpload files={v.fotos} onChange={set("fotos")} /></div>
            <TextArea className="sm:col-span-2" label="Comentarios para el comprador" value={v.comentarios} onChange={set("comentarios")} placeholder="Calibre, estado de la cosecha, empaque…" />
          </div>

          <div className="flex flex-col gap-2.5 rounded-2xl border border-borde bg-brote px-5 py-4">
            <div className="flex justify-between text-[15px]"><span className="text-musgo">Valor estimado del lote</span><span className="font-semibold">{soles(total)}</span></div>
            <div className="flex justify-between text-[15px]"><span className="text-musgo">Tarifa de publicación (7%)</span><span className="font-semibold text-hoja">{soles(comision)}</span></div>
          </div>
        </div>

        <div className="flex flex-wrap justify-between gap-3 px-8 pb-8">
          <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
          <Button type="submit">Publicar lote a compradores</Button>
        </div>
      </form>
    </Modal>
  );
}
