"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import type { FormEvent } from "react";
import { CATEGORIAS, soles, unidadCorta } from "@/lib/constants";
import type { LoteEnVenta } from "@/lib/types";
import { inputCls } from "./ui";

export function LotesExplorer({ lotes }: { lotes: LoteEnVenta[] }) {
  const [texto, setTexto] = useState("");
  const [region, setRegion] = useState("");
  const [categoria, setCategoria] = useState("");

  const regiones = useMemo(() => [...new Set(lotes.map((l) => l.finca.departamento))].sort(), [lotes]);

  const filtrados = lotes.filter((l) => {
    const q = texto.trim().toLowerCase();
    const okTexto = !q || [l.producto, l.finca.nombre_finca, l.finca.departamento, l.finca.provincia].some((s) => s.toLowerCase().includes(q));
    return okTexto && (!region || l.finca.departamento === region) && (!categoria || l.categoria === categoria);
  });

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    console.log("[AgroConnect] Búsqueda de lotes:", { texto, region, categoria });
    // SUPABASE (siguiente paso): supabase.from("v_lotes_en_venta").select("*").ilike("producto", `%${texto}%`)…
  };

  return (
    <>
      <section className="bg-hoja px-6 py-10">
        <div className="mx-auto flex max-w-6xl flex-col gap-5">
          <h1 className="font-display text-4xl font-bold text-white">Lotes en venta</h1>
          <form role="search" onSubmit={handleSubmit} className="flex flex-wrap gap-3">
            <label htmlFor="buscar" className="sr-only">Buscar producto o finca</label>
            <input id="buscar" type="search" value={texto} onChange={(e) => setTexto(e.target.value)} placeholder="Buscar producto, finca o región…" className={`${inputCls} h-13 min-w-[260px] flex-1 border-0`} />
            <label htmlFor="region" className="sr-only">Región</label>
            <select id="region" value={region} onChange={(e) => setRegion(e.target.value)} className={`${inputCls} h-13 w-full border-0 sm:w-52`}>
              <option value="">Todas las regiones</option>
              {regiones.map((r) => <option key={r}>{r}</option>)}
            </select>
            <label htmlFor="categoria" className="sr-only">Categoría</label>
            <select id="categoria" value={categoria} onChange={(e) => setCategoria(e.target.value)} className={`${inputCls} h-13 w-full border-0 sm:w-52`}>
              <option value="">Todas las categorías</option>
              {CATEGORIAS.map((c) => <option key={c}>{c}</option>)}
            </select>
            <button type="submit" className="h-13 rounded-[10px] bg-lima px-7 text-base font-bold text-bosque hover:brightness-95">Buscar</button>
          </form>
        </div>
      </section>

      <main className="mx-auto flex max-w-6xl flex-col gap-5 px-6 pb-20 pt-8">
        <span className="text-sm text-musgo">{filtrados.length} fincas con lotes disponibles</span>
        {filtrados.length === 0 && <p className="rounded-2xl border border-borde bg-white p-8 text-center text-musgo">No encontramos lotes con esos filtros.</p>}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filtrados.map((l) => (
            <Link key={l.id} href={`/lotes/${l.id}`} className="group flex flex-col overflow-hidden rounded-2xl border border-borde bg-white transition hover:-translate-y-0.5 hover:border-hoja">
              <div className="flex h-44 items-end justify-between bg-brote p-3.5">
                <span className="text-[13px] text-musgo">Foto de la finca</span>
                <span className="rounded-full bg-white px-2.5 py-1 text-xs font-semibold text-bosque">{l.categoria}</span>
              </div>
              <div className="flex flex-col gap-2.5 p-4">
                <div className="flex items-center gap-2.5">
                  <span aria-hidden className="flex h-10 w-10 items-center justify-center rounded-full bg-menta text-sm font-bold text-bosque">
                    {l.productor.nombres[0]}{l.productor.apellidos[0]}
                  </span>
                  <div className="flex flex-col">
                    <span className="font-display text-lg font-semibold">{l.finca.nombre_finca}</span>
                    <span className="text-[13px] text-musgo">{l.productor.nombres} {l.productor.apellidos.split(" ")[0]} · {l.finca.provincia}, {l.finca.departamento}</span>
                  </div>
                </div>
                <div className="flex items-baseline justify-between gap-2 border-t border-borde pt-2.5">
                  <span className="text-[15px] font-semibold">{l.producto} · {l.cantidad_estimada.toLocaleString("es-PE")} {unidadCorta(l.unidad)}</span>
                  <span className="whitespace-nowrap font-display text-lg font-bold text-hoja">{soles(l.precio_sugerido)}/{unidadCorta(l.unidad)}</span>
                </div>
                <span className="text-sm font-semibold text-hoja group-hover:underline">Ver lote →</span>
              </div>
            </Link>
          ))}
        </div>
      </main>
    </>
  );
}
