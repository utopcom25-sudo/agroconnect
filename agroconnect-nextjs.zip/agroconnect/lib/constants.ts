import type { FormaEntrega, TipoRiego, Unidad } from "./types";

/** Porcentaje que se cobra por publicar un lote (pago con Yape) */
export const COMISION_PORCENTAJE = 7;
export const COMISION_PUBLICACION = COMISION_PORCENTAJE / 100;

export const UNIDADES: { value: Unidad; label: string; corto: string }[] = [
  { value: "kg", label: "Kilogramos (kg)", corto: "kg" },
  { value: "t", label: "Toneladas (t)", corto: "t" },
  { value: "saco", label: "Sacos", corto: "sacos" },
  { value: "caja", label: "Cajas / jabas", corto: "cajas" },
  { value: "arroba", label: "Arrobas", corto: "arrobas" },
  { value: "unidad", label: "Unidades", corto: "unidades" },
];

export const CATEGORIAS = ["Tubérculos", "Frutas", "Hortalizas", "Granos y cereales", "Café y cacao", "Orgánicos"];

export const CULTIVOS = ["Papa", "Maíz", "Café", "Cacao", "Palta", "Uva", "Arroz", "Quinua", "Cebolla", "Mandarina", "Otro"];

export const DEPARTAMENTOS = [
  "Amazonas", "Áncash", "Apurímac", "Arequipa", "Ayacucho", "Cajamarca", "Callao", "Cusco",
  "Huancavelica", "Huánuco", "Ica", "Junín", "La Libertad", "Lambayeque", "Lima", "Loreto",
  "Madre de Dios", "Moquegua", "Pasco", "Piura", "Puno", "San Martín", "Tacna", "Tumbes", "Ucayali",
];

export const RIEGOS: { value: TipoRiego; label: string }[] = [
  { value: "secano", label: "Secano (lluvia)" },
  { value: "gravedad", label: "Gravedad" },
  { value: "goteo", label: "Goteo" },
  { value: "aspersion", label: "Aspersión" },
];

export const CERTIFICACIONES = ["Orgánico", "Comercio justo", "GlobalG.A.P."];

export const ENTREGAS: { value: FormaEntrega; label: string }[] = [
  { value: "recojo_chacra", label: "Recojo en chacra" },
  { value: "entrega_mercado", label: "Entrega en mercado" },
  { value: "envio_coordinar", label: "Envío a coordinar" },
];

export const CALIDADES = ["Primera", "Segunda", "Tercera", "Mixta"];

export const FRECUENCIAS = ["Semanal", "Quincenal", "Mensual", "Por temporada"];

export const VOLUMENES = ["Menos de 1 tonelada", "1 a 10 toneladas", "10 a 50 toneladas", "Más de 50 toneladas"];

/** Datos de la cuenta Yape de AgroConnect (reemplázalos por los reales) */
export const YAPE = {
  titular: "[NOMBRE DEL TITULAR]",
  numero: "[NÚMERO YAPE]",
  qrSrc: "", // ej. "/yape-qr.png" dentro de /public. Vacío = se muestra un QR de muestra.
};

export const soles = (n: number) =>
  `S/ ${n.toLocaleString("es-PE", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

export const unidadCorta = (u: Unidad) => UNIDADES.find((x) => x.value === u)?.corto ?? u;
