// Datos de EJEMPLO para ver el diseño funcionando.
// En el siguiente paso se reemplazan por consultas a Supabase:
//   supabase.from("v_lotes_en_venta").select("*")
//   supabase.from("v_perfil_productor").select("*").eq("finca_id", id)

import type { LoteEnVenta, Publicacion } from "./types";

// Número de WhatsApp de ejemplo: formato internacional sin "+" (51 = Perú)
const WSP_EJEMPLO = "51999999999";

export const LOTES: LoteEnVenta[] = [
  {
    id: "papa-amarilla-los-andes",
    producto: "Papa amarilla", variedad: "Tumbay", categoria: "Tubérculos",
    cantidad_estimada: 2000, unidad: "kg", precio_sugerido: 2.8,
    calidad: "Primera", disponible_desde: "2026-11-15", entrega: "recojo_chacra",
    comentarios: "Papa seleccionada, calibre mediano a grande. Se entrega en sacos de 50 kg.",
    finca: { nombre_finca: "Finca Los Andes", departamento: "Junín", provincia: "Huancayo", distrito: "Sapallanga" },
    productor: { nombres: "Rosa", apellidos: "Quispe Mamani", edad: 46, telefono_whatsapp: WSP_EJEMPLO, correo: "rosa.quispe@ejemplo.com" },
    historial: [
      { producto: "Haba verde", cantidad: "40 sacos", fecha: "10/10/2026" },
      { producto: "Olluco", cantidad: "800 kg", fecha: "25/09/2026" },
      { producto: "Papa canchán", cantidad: "3 t", fecha: "08/09/2026" },
    ],
  },
  {
    id: "uva-santa-rosa",
    producto: "Uva Red Globe", variedad: "Red Globe", categoria: "Frutas",
    cantidad_estimada: 300, unidad: "caja", precio_sugerido: 38,
    calidad: "Primera", disponible_desde: "2026-12-01", entrega: "entrega_mercado",
    comentarios: "Cajas de 8 kg, cosecha de diciembre.",
    finca: { nombre_finca: "Chacra Santa Rosa", departamento: "Ica", provincia: "Chincha", distrito: "Sunampe" },
    productor: { nombres: "Juan", apellidos: "Mendoza Ríos", edad: 52, telefono_whatsapp: WSP_EJEMPLO, correo: "juan.mendoza@ejemplo.com" },
    historial: [{ producto: "Uva Italia", cantidad: "250 cajas", fecha: "15/01/2026" }],
  },
  {
    id: "cafe-el-mirador",
    producto: "Café pergamino", variedad: "Catimor", categoria: "Café y cacao",
    cantidad_estimada: 25, unidad: "saco", precio_sugerido: 620,
    calidad: "Primera", disponible_desde: "2026-11-20", entrega: "envio_coordinar",
    comentarios: "Sacos de 46 kg, secado al sol.",
    finca: { nombre_finca: "Finca El Mirador", departamento: "Junín", provincia: "Satipo", distrito: "Pangoa" },
    productor: { nombres: "Luis", apellidos: "Huamán Cárdenas", edad: 39, telefono_whatsapp: WSP_EJEMPLO, correo: "luis.huaman@ejemplo.com" },
    historial: [{ producto: "Café pergamino", cantidad: "30 sacos", fecha: "20/07/2026" }],
  },
  {
    id: "mandarina-valle-verde",
    producto: "Mandarina", variedad: "W. Murcott", categoria: "Frutas",
    cantidad_estimada: 4, unidad: "t", precio_sugerido: 1900,
    calidad: "Segunda", disponible_desde: "2026-11-12", entrega: "recojo_chacra",
    comentarios: "Fruta para mercado mayorista.",
    finca: { nombre_finca: "Chacra Valle Verde", departamento: "Lima", provincia: "Huaral", distrito: "Aucallama" },
    productor: { nombres: "María", apellidos: "Torres Vega", edad: 44, telefono_whatsapp: WSP_EJEMPLO, correo: "maria.torres@ejemplo.com" },
    historial: [],
  },
  {
    id: "cacao-san-martin",
    producto: "Cacao en grano", variedad: "CCN-51", categoria: "Café y cacao",
    cantidad_estimada: 900, unidad: "kg", precio_sugerido: 14,
    calidad: "Primera", disponible_desde: "2026-11-18", entrega: "envio_coordinar",
    comentarios: "Grano fermentado y seco.",
    finca: { nombre_finca: "Finca San Martín", departamento: "San Martín", provincia: "Moyobamba", distrito: "Jepelacio" },
    productor: { nombres: "Pedro", apellidos: "Rojas Paredes", edad: 58, telefono_whatsapp: WSP_EJEMPLO, correo: "pedro.rojas@ejemplo.com" },
    historial: [{ producto: "Cacao en grano", cantidad: "700 kg", fecha: "02/08/2026" }],
  },
  {
    id: "cebolla-las-lomas",
    producto: "Cebolla roja", variedad: "Arequipeña", categoria: "Hortalizas",
    cantidad_estimada: 120, unidad: "saco", precio_sugerido: 45,
    calidad: "Primera", disponible_desde: "2026-11-14", entrega: "entrega_mercado",
    comentarios: "Sacos de 50 kg.",
    finca: { nombre_finca: "Chacra Las Lomas", departamento: "Arequipa", provincia: "Arequipa", distrito: "Cerro Colorado" },
    productor: { nombres: "Ana", apellidos: "Flores Ccama", edad: 35, telefono_whatsapp: WSP_EJEMPLO, correo: "ana.flores@ejemplo.com" },
    historial: [{ producto: "Ajo", cantidad: "60 sacos", fecha: "11/05/2026" }],
  },
];

export const getLote = (id: string) => LOTES.find((l) => l.id === id);

export const MIS_PUBLICACIONES: Publicacion[] = [
  { id: "p1", producto: "Papa amarilla", cantidad_estimada: 2000, unidad: "kg", precio_sugerido: 2.8, fecha: "02/11/2026", estado: "activo" },
  { id: "p2", producto: "Papa huayro", cantidad_estimada: 1500, unidad: "kg", precio_sugerido: 2.5, fecha: "20/10/2026", estado: "activo" },
  { id: "p3", producto: "Haba verde", cantidad_estimada: 40, unidad: "saco", precio_sugerido: 85, fecha: "05/10/2026", estado: "vendido" },
  { id: "p4", producto: "Olluco", cantidad_estimada: 800, unidad: "kg", precio_sugerido: 2.2, fecha: "18/09/2026", estado: "vendido" },
];
