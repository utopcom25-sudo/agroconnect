// =====================================================================
//  Cliente de Supabase – PREPARADO PARA EL SIGUIENTE PASO
// =====================================================================
//
//  1. Instala el cliente:
//       npm install @supabase/supabase-js
//
//  2. Crea `.env.local` (copia `.env.local.example`) con:
//       NEXT_PUBLIC_SUPABASE_URL=...
//       NEXT_PUBLIC_SUPABASE_ANON_KEY=...
//     y agrega las mismas variables en Vercel → Settings → Environment Variables.
//
//  3. Descomenta el código de abajo y, en cada formulario, reemplaza el
//     bloque marcado con "SUPABASE (siguiente paso)" por la llamada real.
//
// ---------------------------------------------------------------------
// import { createClient } from "@supabase/supabase-js";
//
// const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
// const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
//
// export const supabase = createClient(supabaseUrl, supabaseAnonKey);
//
// /** Sube un archivo a Supabase Storage y devuelve su URL pública */
// export async function subirArchivo(bucket: string, file: File, carpeta = "") {
//   const ruta = `${carpeta}${crypto.randomUUID()}-${file.name}`;
//   const { error } = await supabase.storage.from(bucket).upload(ruta, file);
//   if (error) throw error;
//   return supabase.storage.from(bucket).getPublicUrl(ruta).data.publicUrl;
// }
// ---------------------------------------------------------------------

export {};
