"use client";

import { useState } from "react";

/**
 * Hook mínimo para formularios controlados.
 * - values: estado actual
 * - set("campo")(valor): actualiza un campo
 * - toggle("campo", valor): agrega/quita un valor en un campo tipo string[]
 */
export function useForm<T extends object>(initial: T) {
  const [values, setValues] = useState<T>(initial);

  const set =
    <K extends keyof T>(key: K) =>
    (value: T[K]) =>
      setValues((v) => ({ ...v, [key]: value }));

  const toggle = <K extends keyof T>(key: K, item: string) =>
    setValues((v) => {
      const list = (v[key] as unknown as string[]) ?? [];
      const next = list.includes(item) ? list.filter((x) => x !== item) : [...list, item];
      return { ...v, [key]: next };
    });

  const reset = () => setValues(initial);

  return { values, set, toggle, reset, setValues };
}
