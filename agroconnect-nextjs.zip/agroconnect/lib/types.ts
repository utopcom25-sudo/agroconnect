// Tipos de los formularios. Los nombres de campo coinciden con las columnas
// de la base de datos (agroconnect_schema.sql) para poder enviarlos directo
// a Supabase en el siguiente paso.

export type TipoUsuario = "agricultor" | "comprador_persona" | "comprador_empresa";
export type Unidad = "kg" | "t" | "saco" | "caja" | "arroba" | "unidad";
export type FormaEntrega = "recojo_chacra" | "entrega_mercado" | "envio_coordinar";
export type TipoRiego = "secano" | "gravedad" | "goteo" | "aspersion";

/** Datos personales (agricultor y comprador persona) → tabla `usuarios` */
export interface DatosPersonalesForm {
  nombres: string;
  apellidos: string;
  fecha_nacimiento: string; // "YYYY-MM-DD"
  correo: string;
  usuario: string;
  telefono_whatsapp: string;
  password: string;
  confirmar_password: string;
  foto_perfil: File | null; // se subirá a Supabase Storage
}

/** Perfil de la chacra / finca → tablas `fincas` y `finca_certificaciones` */
export interface FincaForm {
  nombre_finca: string;
  nombre_productor: string;
  cultivo_principal: string;
  otros_cultivos: string;
  area_hectareas: string;
  riego: TipoRiego | "";
  departamento: string;
  provincia: string;
  distrito: string;
  direccion_referencia: string;
  certificaciones: string[];
  descripcion: string;
}

/** Comprador persona → `usuarios` + `perfiles_comprador` + `preferencias_compra` */
export interface CompradorPersonaForm extends DatosPersonalesForm {
  preferencias: string[];
  frecuencia_compra: string;
  zona_entrega: string;
}

/** Comprador empresa → `empresas` + `preferencias_compra` */
export interface EmpresaForm {
  nombre_comercial: string;
  ruc: string;
  preferencias: string[];
  volumen_mensual: string;
  detalle_busqueda: string;
}

/** Ofrecer lote de cosecha → tablas `lotes` y `lote_fotos` */
export interface LoteForm {
  producto: string;
  variedad: string;
  cantidad_estimada: string;
  unidad: Unidad;
  precio_sugerido: string;
  // Pestaña "Detalles extra"
  calidad: string;
  disponible_desde: string;
  entrega: FormaEntrega;
  comentarios: string;
  fotos: File[];
}

/** Pago de publicación con Yape → tabla `pagos_publicacion` */
export interface PagoYapeForm {
  monto_base: string;
  numero_operacion: string;
  captura: File | null;
}

/** Datos que muestran las pantallas (vienen de las vistas de la BD) */
export interface Productor {
  nombres: string;
  apellidos: string;
  edad: number;
  telefono_whatsapp: string; // formato internacional sin "+", ej. 51987654321
  correo: string;
}

export interface Venta {
  producto: string;
  cantidad: string;
  fecha: string;
}

export interface LoteEnVenta {
  id: string;
  producto: string;
  variedad: string;
  categoria: string;
  cantidad_estimada: number;
  unidad: Unidad;
  precio_sugerido: number;
  calidad: string;
  disponible_desde: string;
  entrega: FormaEntrega;
  comentarios: string;
  finca: {
    nombre_finca: string;
    departamento: string;
    provincia: string;
    distrito: string;
  };
  productor: Productor;
  historial: Venta[];
}

export interface Publicacion {
  id: string;
  producto: string;
  cantidad_estimada: number;
  unidad: Unidad;
  precio_sugerido: number;
  fecha: string;
  estado: "activo" | "vendido" | "vencido" | "pendiente_pago";
}
